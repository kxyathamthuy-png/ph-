/** @type {const} */
const themeColors = {
  primary: { light: '#2E7D32', dark: '#66BB6A' },
  background: { light: '#F1F8E9', dark: '#1B2A1B' },
  surface: { light: '#FFFFFF', dark: '#243024' },
  foreground: { light: '#1B3A1B', dark: '#E8F5E9' },
  muted: { light: '#5D7A5D', dark: '#90A890' },
  border: { light: '#C8E6C9', dark: '#2E5030' },
  success: { light: '#2E7D32', dark: '#66BB6A' },
  warning: { light: '#F9A825', dark: '#FFCA28' },
  error: { light: '#C62828', dark: '#EF9A9A' },
  soil: { light: '#795548', dark: '#A1887F' },
  acid: { light: '#E53935', dark: '#EF9A9A' },
  neutral: { light: '#2E7D32', dark: '#66BB6A' },
  alkaline: { light: '#1565C0', dark: '#64B5F6' },
};

module.exports = { themeColors };
