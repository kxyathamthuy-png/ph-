import React, { useState, useCallback } from "react";
import {
  ScrollView,
  Text,
  View,
  TextInput,
  Pressable,
  FlatList,
  StyleSheet,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getPlantsForPH, getPHStatus, PLANTS, type Plant } from "@/constants/plants";

const PH_MIN = 0;
const PH_MAX = 14;
const PH_COLORS = [
  "#C62828", "#E53935", "#E53935", "#EF6C00",
  "#FB8C00", "#F9A825", "#66BB6A", "#2E7D32",
  "#26A69A", "#1565C0", "#1565C0", "#4527A0",
  "#4527A0", "#311B92", "#1A237E",
];

function getPHColor(ph: number): string {
  const idx = Math.min(Math.floor(ph), 14);
  return PH_COLORS[idx] ?? "#2E7D32";
}

function PHScaleBar({ value }: { value: number }) {
  const percent = (value / PH_MAX) * 100;
  return (
    <View style={styles.scaleBarContainer}>
      <View style={styles.scaleBarGradient}>
        {PH_COLORS.slice(0, 14).map((color, i) => (
          <View key={i} style={[styles.scaleBarSegment, { backgroundColor: color }]} />
        ))}
      </View>
      <View style={[styles.scaleBarIndicator, { left: `${percent}%` as any }]}>
        <View style={[styles.scaleBarPin, { backgroundColor: getPHColor(value) }]} />
        <Text style={[styles.scaleBarPinLabel, { color: getPHColor(value) }]}>
          {value.toFixed(1)}
        </Text>
      </View>
      <View style={styles.scaleBarLabels}>
        <Text style={styles.scaleBarLabelText}>0</Text>
        <Text style={styles.scaleBarLabelText}>7</Text>
        <Text style={styles.scaleBarLabelText}>14</Text>
      </View>
    </View>
  );
}

function PlantCard({ plant, onPress }: { plant: Plant; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.plantCard,
        { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
      ]}
      onPress={onPress}
    >
      <Text style={styles.plantEmoji}>{plant.emoji}</Text>
      <View style={styles.plantInfo}>
        <Text style={[styles.plantName, { color: colors.foreground }]}>{plant.name}</Text>
        <Text style={[styles.plantPH, { color: colors.primary }]}>
          pH {plant.phMin}–{plant.phMax}
        </Text>
      </View>
      <Text style={[styles.plantArrow, { color: colors.muted }]}>›</Text>
    </Pressable>
  );
}

export default function CheckerScreen() {
  const colors = useColors();
  const router = useRouter();
  const [phValue, setPhValue] = useState(6.5);
  const [inputText, setInputText] = useState("6.5");
  const [inputError, setInputError] = useState("");

  const matchedPlants = getPlantsForPH(phValue);
  const status = getPHStatus(phValue);

  const handleSliderChange = useCallback((delta: number) => {
    const newVal = Math.max(PH_MIN, Math.min(PH_MAX, parseFloat((phValue + delta).toFixed(1))));
    setPhValue(newVal);
    setInputText(newVal.toFixed(1));
    setInputError("");
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, [phValue]);

  const handleInputChange = (text: string) => {
    setInputText(text);
    const num = parseFloat(text);
    if (!isNaN(num) && num >= PH_MIN && num <= PH_MAX) {
      setPhValue(num);
      setInputError("");
    } else if (text !== "" && text !== ".") {
      setInputError("กรุณากรอกค่า pH ระหว่าง 0–14");
    }
  };

  const handlePlantPress = (plant: Plant) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push({ pathname: "/plant-detail", params: { id: plant.id } } as any);
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Title */}
        <View style={[styles.titleBar, { backgroundColor: colors.primary }]}>
          <Text style={styles.titleText}>💧 ตรวจสอบค่า pH ดิน</Text>
          <Text style={styles.titleSub}>กรอกค่า pH ที่วัดได้จากดินของคุณ</Text>
        </View>

        <View style={styles.body}>
          {/* Input Section */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardLabel, { color: colors.foreground }]}>ค่า pH ที่วัดได้</Text>

            <View style={styles.inputRow}>
              <Pressable
                style={[styles.stepBtn, { backgroundColor: colors.primary }]}
                onPress={() => handleSliderChange(-0.5)}
              >
                <Text style={styles.stepBtnText}>−</Text>
              </Pressable>

              <TextInput
                style={[
                  styles.phInput,
                  {
                    color: getPHColor(phValue),
                    borderColor: inputError ? "#C62828" : colors.border,
                    backgroundColor: colors.background,
                  },
                ]}
                value={inputText}
                onChangeText={handleInputChange}
                keyboardType="decimal-pad"
                maxLength={5}
                textAlign="center"
                returnKeyType="done"
              />

              <Pressable
                style={[styles.stepBtn, { backgroundColor: colors.primary }]}
                onPress={() => handleSliderChange(0.5)}
              >
                <Text style={styles.stepBtnText}>+</Text>
              </Pressable>
            </View>

            {inputError ? (
              <Text style={styles.errorText}>{inputError}</Text>
            ) : null}

            {/* Fine adjustment */}
            <View style={styles.fineRow}>
              {[-1, -0.1, 0.1, 1].map((delta) => (
                <Pressable
                  key={delta}
                  style={({ pressed }) => [
                    styles.fineBtn,
                    { backgroundColor: colors.background, borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
                  ]}
                  onPress={() => handleSliderChange(delta)}
                >
                  <Text style={[styles.fineBtnText, { color: colors.foreground }]}>
                    {delta > 0 ? `+${delta}` : delta}
                  </Text>
                </Pressable>
              ))}
            </View>

            {/* pH Scale Bar */}
            <PHScaleBar value={phValue} />
          </View>

          {/* Status Card */}
          <View style={[styles.statusCard, { backgroundColor: status.color + "18", borderColor: status.color + "50" }]}>
            <View style={[styles.statusBadge, { backgroundColor: status.color }]}>
              <Text style={styles.statusBadgeText}>{status.label}</Text>
            </View>
            <Text style={[styles.statusDesc, { color: colors.foreground }]}>{status.description}</Text>
          </View>

          {/* Matched Plants */}
          <View style={styles.resultSection}>
            <Text style={[styles.resultTitle, { color: colors.foreground }]}>
              🌱 พืชที่เหมาะสม ({matchedPlants.length} ชนิด)
            </Text>
            {matchedPlants.length === 0 ? (
              <View style={[styles.emptyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={styles.emptyIcon}>😔</Text>
                <Text style={[styles.emptyText, { color: colors.muted }]}>
                  ไม่พบพืชที่เหมาะสมกับค่า pH นี้{"\n"}ลองปรับปรุงดินก่อนปลูก
                </Text>
              </View>
            ) : (
              matchedPlants.map((plant) => (
                <PlantCard key={plant.id} plant={plant} onPress={() => handlePlantPress(plant)} />
              ))
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  titleBar: {
    paddingTop: 24,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  titleText: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  titleSub: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginTop: 4,
  },
  body: {
    padding: 16,
    gap: 14,
  },
  card: {
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    gap: 14,
  },
  cardLabel: {
    fontSize: 15,
    fontWeight: "600",
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  stepBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  stepBtnText: {
    fontSize: 24,
    fontWeight: "600",
    color: "#FFFFFF",
    lineHeight: 28,
  },
  phInput: {
    width: 100,
    height: 64,
    borderRadius: 16,
    borderWidth: 2,
    fontSize: 32,
    fontWeight: "800",
    textAlign: "center",
  },
  errorText: {
    color: "#C62828",
    fontSize: 12,
    textAlign: "center",
  },
  fineRow: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  fineBtn: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  fineBtnText: {
    fontSize: 13,
    fontWeight: "600",
  },
  scaleBarContainer: {
    marginTop: 4,
    position: "relative",
    paddingBottom: 20,
  },
  scaleBarGradient: {
    flexDirection: "row",
    height: 16,
    borderRadius: 8,
    overflow: "hidden",
  },
  scaleBarSegment: {
    flex: 1,
  },
  scaleBarIndicator: {
    position: "absolute",
    top: -4,
    alignItems: "center",
    transform: [{ translateX: -8 }],
  },
  scaleBarPin: {
    width: 16,
    height: 24,
    borderRadius: 3,
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  scaleBarPinLabel: {
    fontSize: 11,
    fontWeight: "700",
    marginTop: 2,
  },
  scaleBarLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 4,
  },
  scaleBarLabelText: {
    fontSize: 11,
    color: "#9E9E9E",
    fontWeight: "500",
  },
  statusCard: {
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusBadgeText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
  },
  statusDesc: {
    flex: 1,
    fontSize: 13,
    lineHeight: 19,
  },
  resultSection: {
    gap: 8,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 2,
  },
  plantCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 12,
  },
  plantEmoji: {
    fontSize: 28,
  },
  plantInfo: {
    flex: 1,
  },
  plantName: {
    fontSize: 15,
    fontWeight: "600",
  },
  plantPH: {
    fontSize: 13,
    fontWeight: "500",
    marginTop: 2,
  },
  plantArrow: {
    fontSize: 22,
    fontWeight: "300",
  },
  emptyCard: {
    borderRadius: 14,
    padding: 24,
    borderWidth: 1,
    alignItems: "center",
    gap: 8,
  },
  emptyIcon: {
    fontSize: 40,
  },
  emptyText: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 21,
  },
});
