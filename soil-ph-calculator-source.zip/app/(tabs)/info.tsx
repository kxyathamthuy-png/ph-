import React from "react";
import { ScrollView, Text, View, StyleSheet } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const PH_TABLE = [
  { range: "< 4.0", label: "กรดจัดมาก", color: "#C62828", effect: "พืชส่วนใหญ่ไม่สามารถเจริญเติบโตได้" },
  { range: "4.0–5.0", label: "กรดจัด", color: "#E53935", effect: "เหมาะสำหรับชา สับปะรด บลูเบอร์รี่" },
  { range: "5.0–6.0", label: "กรดอ่อน", color: "#FB8C00", effect: "เหมาะสำหรับพืชหลายชนิด เช่น กล้วย ส้ม" },
  { range: "6.0–7.0", label: "เป็นกลาง", color: "#2E7D32", effect: "เหมาะสำหรับพืชส่วนใหญ่ สารอาหารละลายได้ดีที่สุด" },
  { range: "7.0–8.0", label: "ด่างอ่อน", color: "#1565C0", effect: "เหมาะสำหรับอ้อย กระบองเพชร" },
  { range: "> 8.0", label: "ด่างจัด", color: "#4527A0", effect: "พืชส่วนใหญ่ดูดซึมสารอาหารได้น้อยลง" },
];

const ADJUSTMENT_TIPS = [
  {
    title: "เพิ่มความเป็นกรด (ลด pH)",
    icon: "🔴",
    tips: [
      "ใส่กำมะถัน (Elemental Sulfur)",
      "ใส่ปุ๋ยแอมโมเนียมซัลเฟต",
      "ใส่พีทมอส (Peat Moss)",
      "ใส่เปลือกสน (Pine Bark)",
    ],
  },
  {
    title: "เพิ่มความเป็นด่าง (เพิ่ม pH)",
    icon: "🔵",
    tips: [
      "ใส่ปูนขาว (Agricultural Lime)",
      "ใส่ปูนมาร์ล (Marl)",
      "ใส่เถ้าไม้หรือเถ้าฟาง",
      "ใส่ปุ๋ยหินฟอสเฟต",
    ],
  },
];

export default function InfoScreen() {
  const colors = useColors();

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: "#1565C0" }]}>
          <Text style={styles.headerTitle}>ℹ️ ข้อมูลค่า pH ดิน</Text>
          <Text style={styles.headerSub}>ความรู้เกี่ยวกับค่า pH และการปรับปรุงดิน</Text>
        </View>

        <View style={styles.body}>
          {/* What is pH */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>🌍 ค่า pH ในดินคืออะไร?</Text>
            <Text style={[styles.cardText, { color: colors.foreground }]}>
              ค่า pH วัดระดับความเป็นกรด-ด่างของดิน โดยมีค่าตั้งแต่ 0 ถึง 14 ค่า pH 7.0 คือกลาง ต่ำกว่า 7.0 คือกรด และสูงกว่า 7.0 คือด่าง
            </Text>
            <Text style={[styles.cardText, { color: colors.foreground, marginTop: 8 }]}>
              ค่า pH ส่งผลต่อการละลายของสารอาหารในดิน ทำให้พืชดูดซึมธาตุอาหารได้มากหรือน้อย ดินที่มีค่า pH เหมาะสมจะช่วยให้พืชเจริญเติบโตได้ดีที่สุด
            </Text>
          </View>

          {/* pH Table */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ตารางระดับค่า pH</Text>
          <View style={[styles.tableCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {PH_TABLE.map((row, index) => (
              <View
                key={row.range}
                style={[
                  styles.tableRow,
                  index < PH_TABLE.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border },
                ]}
              >
                <View style={[styles.tableColorBar, { backgroundColor: row.color }]} />
                <View style={styles.tableContent}>
                  <View style={styles.tableTopRow}>
                    <Text style={[styles.tableRange, { color: colors.foreground }]}>pH {row.range}</Text>
                    <View style={[styles.tableBadge, { backgroundColor: row.color + "20" }]}>
                      <Text style={[styles.tableBadgeText, { color: row.color }]}>{row.label}</Text>
                    </View>
                  </View>
                  <Text style={[styles.tableEffect, { color: colors.muted }]}>{row.effect}</Text>
                </View>
              </View>
            ))}
          </View>

          {/* How to measure */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>วิธีวัดค่า pH ดิน</Text>
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {[
              { num: "1", text: "ใช้ชุดทดสอบ pH (pH Test Kit) — ราคาถูก หาซื้อง่ายตามร้านเกษตร" },
              { num: "2", text: "ใช้เครื่องวัด pH ดิจิทัล (pH Meter) — แม่นยำกว่า เหมาะสำหรับการใช้งานบ่อย" },
              { num: "3", text: "ส่งตัวอย่างดินไปตรวจที่ห้องปฏิบัติการ — ได้ผลละเอียดที่สุด" },
            ].map((step) => (
              <View key={step.num} style={styles.stepRow}>
                <View style={[styles.stepNum, { backgroundColor: colors.primary }]}>
                  <Text style={styles.stepNumText}>{step.num}</Text>
                </View>
                <Text style={[styles.stepText, { color: colors.foreground }]}>{step.text}</Text>
              </View>
            ))}
          </View>

          {/* Adjustment Tips */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>การปรับปรุงค่า pH ดิน</Text>
          {ADJUSTMENT_TIPS.map((section) => (
            <View key={section.title} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                {section.icon} {section.title}
              </Text>
              {section.tips.map((tip, i) => (
                <View key={i} style={styles.tipRow}>
                  <Text style={[styles.tipDot, { color: colors.primary }]}>•</Text>
                  <Text style={[styles.tipText, { color: colors.foreground }]}>{tip}</Text>
                </View>
              ))}
            </View>
          ))}

          {/* Note */}
          <View style={[styles.noteCard, { backgroundColor: "#FFF8E1", borderColor: "#FFE082" }]}>
            <Text style={styles.noteIcon}>⚠️</Text>
            <Text style={[styles.noteText, { color: "#5D4037" }]}>
              การปรับค่า pH ดินควรทำทีละน้อยและตรวจสอบซ้ำหลังจาก 2–4 สัปดาห์ การเปลี่ยนแปลงอย่างรวดเร็วอาจทำให้พืชเสียหายได้
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  headerSub: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginTop: 4,
  },
  body: {
    padding: 16,
    gap: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginTop: 6,
    marginBottom: 2,
  },
  card: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    gap: 10,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  cardText: {
    fontSize: 14,
    lineHeight: 22,
  },
  tableCard: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
  },
  tableRow: {
    flexDirection: "row",
    padding: 12,
    gap: 10,
    alignItems: "flex-start",
  },
  tableColorBar: {
    width: 5,
    borderRadius: 3,
    minHeight: 40,
  },
  tableContent: {
    flex: 1,
    gap: 4,
  },
  tableTopRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flexWrap: "wrap",
  },
  tableRange: {
    fontSize: 14,
    fontWeight: "700",
  },
  tableBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  tableBadgeText: {
    fontSize: 12,
    fontWeight: "600",
  },
  tableEffect: {
    fontSize: 13,
    lineHeight: 18,
  },
  stepRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  stepNum: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    marginTop: 1,
  },
  stepNumText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
  },
  stepText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 21,
  },
  tipRow: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-start",
  },
  tipDot: {
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 22,
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 22,
  },
  noteCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 10,
    marginTop: 4,
  },
  noteIcon: {
    fontSize: 20,
    marginTop: 1,
  },
  noteText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 20,
  },
});
