import React, { useState, useMemo } from "react";
import {
  Text,
  View,
  TextInput,
  Pressable,
  FlatList,
  StyleSheet,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { PLANTS, CATEGORY_LABELS, type Plant, type PlantCategory } from "@/constants/plants";

const CATEGORIES: PlantCategory[] = [
  "vegetable",
  "field_crop",
  "fruit_tree",
  "flower",
  "acid_loving",
  "alkaline_tolerant",
];

export default function PlantsScreen() {
  const colors = useColors();
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<PlantCategory | "all">("all");

  const filteredPlants = useMemo(() => {
    let result = PLANTS;
    if (selectedCategory !== "all") {
      result = result.filter((p) => p.category === selectedCategory);
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      result = result.filter((p) => p.name.toLowerCase().includes(q));
    }
    return result;
  }, [search, selectedCategory]);

  const handlePlantPress = (plant: Plant) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push({ pathname: "/plant-detail", params: { id: plant.id } } as any);
  };

  const renderPlant = ({ item }: { item: Plant }) => (
    <Pressable
      style={({ pressed }) => [
        styles.plantCard,
        { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
      ]}
      onPress={() => handlePlantPress(item)}
    >
      <Text style={styles.plantEmoji}>{item.emoji}</Text>
      <View style={styles.plantInfo}>
        <Text style={[styles.plantName, { color: colors.foreground }]}>{item.name}</Text>
        <Text style={[styles.plantCategory, { color: colors.muted }]}>
          {CATEGORY_LABELS[item.category].replace(/^[^\s]+\s/, "")}
        </Text>
      </View>
      <View style={styles.plantPHBadge}>
        <Text style={[styles.plantPHText, { color: colors.primary }]}>
          {item.phMin}–{item.phMax}
        </Text>
        <Text style={[styles.plantPHLabel, { color: colors.muted }]}>pH</Text>
      </View>
      <Text style={[styles.arrow, { color: colors.muted }]}>›</Text>
    </Pressable>
  );

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: "#795548" }]}>
        <Text style={styles.headerTitle}>🌱 ค้นหาพืช</Text>
        <Text style={styles.headerSub}>ค้นหาค่า pH ที่เหมาะสมสำหรับพืชที่ต้องการปลูก</Text>
      </View>

      {/* Search */}
      <View style={[styles.searchContainer, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="ค้นหาชื่อพืช..."
            placeholderTextColor={colors.muted}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")}>
              <Text style={[styles.clearBtn, { color: colors.muted }]}>✕</Text>
            </Pressable>
          )}
        </View>
      </View>

      {/* Category Filter */}
      <View style={[styles.filterContainer, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={[{ id: "all", label: "ทั้งหมด" }, ...CATEGORIES.map((c) => ({ id: c, label: CATEGORY_LABELS[c] }))]}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 12, gap: 8, paddingVertical: 8 }}
          renderItem={({ item }) => {
            const isActive = selectedCategory === item.id;
            return (
              <Pressable
                style={({ pressed }) => [
                  styles.filterChip,
                  {
                    backgroundColor: isActive ? colors.primary : colors.surface,
                    borderColor: isActive ? colors.primary : colors.border,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                onPress={() => {
                  setSelectedCategory(item.id as any);
                  if (Platform.OS !== "web") {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }
                }}
              >
                <Text style={[styles.filterChipText, { color: isActive ? "#FFFFFF" : colors.foreground }]}>
                  {item.label}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      {/* Plant List */}
      <FlatList
        data={filteredPlants}
        keyExtractor={(item) => item.id}
        renderItem={renderPlant}
        contentContainerStyle={{ padding: 12, gap: 8, paddingBottom: 32 }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🔍</Text>
            <Text style={[styles.emptyText, { color: colors.muted }]}>ไม่พบพืชที่ค้นหา</Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  headerSub: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginTop: 4,
  },
  searchContainer: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
  },
  searchIcon: {
    fontSize: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    padding: 0,
  },
  clearBtn: {
    fontSize: 16,
    padding: 2,
  },
  filterContainer: {
    borderBottomWidth: 1,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterChipText: {
    fontSize: 13,
    fontWeight: "500",
  },
  plantCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 12,
  },
  plantEmoji: {
    fontSize: 30,
  },
  plantInfo: {
    flex: 1,
  },
  plantName: {
    fontSize: 15,
    fontWeight: "600",
  },
  plantCategory: {
    fontSize: 12,
    marginTop: 2,
  },
  plantPHBadge: {
    alignItems: "center",
  },
  plantPHText: {
    fontSize: 14,
    fontWeight: "700",
  },
  plantPHLabel: {
    fontSize: 11,
    fontWeight: "500",
  },
  arrow: {
    fontSize: 22,
    fontWeight: "300",
  },
  emptyContainer: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  emptyIcon: {
    fontSize: 48,
  },
  emptyText: {
    fontSize: 15,
  },
});
