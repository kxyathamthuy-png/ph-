import { ScrollView, Text, View, Pressable, Image, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const PH_SCALE = [
  { ph: "0–3", label: "กรดจัดมาก", color: "#C62828" },
  { ph: "3–5", label: "กรดจัด", color: "#E53935" },
  { ph: "5–6", label: "กรดอ่อน", color: "#FB8C00" },
  { ph: "6–7", label: "เป็นกลาง", color: "#2E7D32" },
  { ph: "7–8", label: "ด่างอ่อน", color: "#1565C0" },
  { ph: "8+", label: "ด่างจัด", color: "#4527A0" },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();

  const handlePress = (route: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push(route as any);
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.appTitle}>pH ดิน</Text>
          <Text style={styles.appSubtitle}>ตรวจสอบค่า pH ดินสำหรับปลูกพืช</Text>
        </View>

        <View style={styles.content}>
          {/* Quick Action Buttons */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>เริ่มต้นใช้งาน</Text>

          <Pressable
            style={({ pressed }) => [
              styles.actionCard,
              { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={() => handlePress("/(tabs)/checker")}
          >
            <Text style={styles.actionIcon}>💧</Text>
            <View style={styles.actionTextContainer}>
              <Text style={styles.actionTitle}>ตรวจสอบค่า pH</Text>
              <Text style={styles.actionDesc}>ป้อนค่า pH ดินที่วัดได้ เพื่อดูพืชที่เหมาะสม</Text>
            </View>
            <Text style={styles.actionArrow}>›</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.actionCard,
              { backgroundColor: "#795548", opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={() => handlePress("/(tabs)/plants")}
          >
            <Text style={styles.actionIcon}>🌱</Text>
            <View style={styles.actionTextContainer}>
              <Text style={styles.actionTitle}>ค้นหาพืช</Text>
              <Text style={styles.actionDesc}>ค้นหาค่า pH ที่เหมาะสมสำหรับพืชที่ต้องการปลูก</Text>
            </View>
            <Text style={styles.actionArrow}>›</Text>
          </Pressable>

          {/* pH Scale Summary */}
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ระดับค่า pH ในดิน</Text>
          <View style={[styles.scaleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {PH_SCALE.map((item) => (
              <View key={item.ph} style={styles.scaleRow}>
                <View style={[styles.scaleColorDot, { backgroundColor: item.color }]} />
                <Text style={[styles.scalePhText, { color: colors.foreground }]}>pH {item.ph}</Text>
                <Text style={[styles.scaleLabelText, { color: item.color }]}>{item.label}</Text>
              </View>
            ))}
          </View>

          {/* Info Card */}
          <View style={[styles.infoCard, { backgroundColor: "#E8F5E9", borderColor: "#A5D6A7" }]}>
            <Text style={styles.infoIcon}>💡</Text>
            <Text style={[styles.infoText, { color: "#1B5E20" }]}>
              ค่า pH ในดินที่เหมาะสมสำหรับพืชส่วนใหญ่อยู่ที่ <Text style={{ fontWeight: "700" }}>6.0–7.0</Text> ซึ่งเป็นช่วงที่สารอาหารในดินละลายได้ดีที่สุด
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: "center",
    paddingTop: 32,
    paddingBottom: 32,
    paddingHorizontal: 24,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 20,
    marginBottom: 12,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: "800",
    color: "#FFFFFF",
    letterSpacing: 0.5,
  },
  appSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.85)",
    marginTop: 4,
    textAlign: "center",
  },
  content: {
    padding: 20,
    gap: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginTop: 8,
    marginBottom: 4,
  },
  actionCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 16,
    padding: 18,
    gap: 14,
  },
  actionIcon: {
    fontSize: 32,
  },
  actionTextContainer: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 3,
  },
  actionDesc: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    lineHeight: 18,
  },
  actionArrow: {
    fontSize: 24,
    color: "rgba(255,255,255,0.7)",
    fontWeight: "300",
  },
  scaleCard: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    gap: 10,
  },
  scaleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  scaleColorDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  scalePhText: {
    fontSize: 14,
    fontWeight: "600",
    width: 70,
  },
  scaleLabelText: {
    fontSize: 14,
    fontWeight: "500",
  },
  infoCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 10,
    marginTop: 4,
  },
  infoIcon: {
    fontSize: 20,
    marginTop: 1,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 21,
  },
});
