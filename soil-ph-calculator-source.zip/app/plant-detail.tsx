import React, { useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  TextInput,
  StyleSheet,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  PLANTS,
  CATEGORY_LABELS,
  getPHStatus,
  getSoilAdjustmentAdvice,
} from "@/constants/plants";

const PH_COLORS = [
  "#C62828", "#E53935", "#E53935", "#EF6C00",
  "#FB8C00", "#F9A825", "#66BB6A", "#2E7D32",
  "#26A69A", "#1565C0", "#1565C0", "#4527A0",
  "#4527A0", "#311B92", "#1A237E",
];

function getPHColor(ph: number): string {
  const idx = Math.min(Math.floor(ph), 14);
  return PH_COLORS[idx] ?? "#2E7D32";
}

function PHRangeBar({ phMin, phMax, currentPH }: { phMin: number; phMax: number; currentPH?: number }) {
  const minPct = (phMin / 14) * 100;
  const maxPct = (phMax / 14) * 100;
  const widthPct = maxPct - minPct;
  const currentPct = currentPH !== undefined ? (currentPH / 14) * 100 : undefined;

  return (
    <View style={styles.rangeBarContainer}>
      {/* Background track */}
      <View style={styles.rangeTrack}>
        {PH_COLORS.slice(0, 14).map((color, i) => (
          <View key={i} style={[styles.rangeTrackSegment, { backgroundColor: color, opacity: 0.3 }]} />
        ))}
      </View>
      {/* Optimal range highlight */}
      <View
        style={[
          styles.rangeHighlight,
          {
            left: `${minPct}%` as any,
            width: `${widthPct}%` as any,
            backgroundColor: "#2E7D32",
          },
        ]}
      />
      {/* Current pH indicator */}
      {currentPH !== undefined && (
        <View style={[styles.currentPHPin, { left: `${currentPct}%` as any }]}>
          <View style={[styles.currentPHPinHead, { backgroundColor: getPHColor(currentPH) }]} />
        </View>
      )}
      {/* Labels */}
      <View style={styles.rangeLabels}>
        <Text style={styles.rangeLabelText}>0</Text>
        <Text style={styles.rangeLabelText}>pH ที่เหมาะสม: {phMin}–{phMax}</Text>
        <Text style={styles.rangeLabelText}>14</Text>
      </View>
    </View>
  );
}

export default function PlantDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const router = useRouter();
  const [myPH, setMyPH] = useState("");

  const plant = PLANTS.find((p) => p.id === id);

  if (!plant) {
    return (
      <ScreenContainer className="items-center justify-center p-8">
        <Text style={[styles.notFoundText, { color: colors.muted }]}>ไม่พบข้อมูลพืช</Text>
        <Pressable
          style={[styles.backBtn, { backgroundColor: colors.primary }]}
          onPress={() => router.back()}
        >
          <Text style={styles.backBtnText}>กลับ</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  const myPHNum = parseFloat(myPH);
  const isValidPH = !isNaN(myPHNum) && myPHNum >= 0 && myPHNum <= 14;
  const advice = isValidPH ? getSoilAdjustmentAdvice(myPHNum, plant.phMin, plant.phMax) : null;
  const myPHStatus = isValidPH ? getPHStatus(myPHNum) : null;
  const isCompatible = isValidPH && myPHNum >= plant.phMin && myPHNum <= plant.phMax;

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <Pressable
            style={({ pressed }) => [styles.headerBackBtn, { opacity: pressed ? 0.7 : 1 }]}
            onPress={() => {
              if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              router.back();
            }}
          >
            <Text style={styles.headerBackText}>‹ กลับ</Text>
          </Pressable>
          <Text style={styles.plantEmoji}>{plant.emoji}</Text>
          <Text style={styles.plantName}>{plant.name}</Text>
          <Text style={[styles.plantCategory, { color: "rgba(255,255,255,0.85)" }]}>
            {CATEGORY_LABELS[plant.category]}
          </Text>
        </View>

        <View style={styles.body}>
          {/* pH Range Card */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>ค่า pH ที่เหมาะสม</Text>
            <View style={styles.phRangeRow}>
              <View style={[styles.phBadge, { backgroundColor: colors.primary + "20" }]}>
                <Text style={[styles.phBadgeMin, { color: colors.primary }]}>{plant.phMin}</Text>
                <Text style={[styles.phBadgeSep, { color: colors.muted }]}> – </Text>
                <Text style={[styles.phBadgeMax, { color: colors.primary }]}>{plant.phMax}</Text>
              </View>
            </View>
            <PHRangeBar phMin={plant.phMin} phMax={plant.phMax} currentPH={isValidPH ? myPHNum : undefined} />
            {plant.notes && (
              <View style={[styles.noteRow, { backgroundColor: "#FFF8E1", borderColor: "#FFE082" }]}>
                <Text style={styles.noteIcon}>💡</Text>
                <Text style={[styles.noteText, { color: "#5D4037" }]}>{plant.notes}</Text>
              </View>
            )}
          </View>

          {/* My Soil pH Checker */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>🧪 ตรวจสอบดินของคุณ</Text>
            <Text style={[styles.cardSub, { color: colors.muted }]}>กรอกค่า pH ดินที่วัดได้</Text>
            <View style={styles.myPHRow}>
              <TextInput
                style={[
                  styles.myPHInput,
                  {
                    borderColor: isValidPH
                      ? isCompatible
                        ? "#2E7D32"
                        : "#C62828"
                      : colors.border,
                    color: isValidPH ? getPHColor(myPHNum) : colors.foreground,
                    backgroundColor: colors.background,
                  },
                ]}
                placeholder="เช่น 6.5"
                placeholderTextColor={colors.muted}
                value={myPH}
                onChangeText={setMyPH}
                keyboardType="decimal-pad"
                maxLength={5}
                returnKeyType="done"
              />
              {isValidPH && (
                <View
                  style={[
                    styles.compatBadge,
                    { backgroundColor: isCompatible ? "#E8F5E9" : "#FFEBEE" },
                  ]}
                >
                  <Text style={{ fontSize: 20 }}>{isCompatible ? "✅" : "❌"}</Text>
                  <Text
                    style={[
                      styles.compatText,
                      { color: isCompatible ? "#2E7D32" : "#C62828" },
                    ]}
                  >
                    {isCompatible ? "เหมาะสม" : "ไม่เหมาะสม"}
                  </Text>
                </View>
              )}
            </View>

            {advice && (
              <View
                style={[
                  styles.adviceBox,
                  {
                    backgroundColor: isCompatible ? "#E8F5E9" : "#FFF3E0",
                    borderColor: isCompatible ? "#A5D6A7" : "#FFCC80",
                  },
                ]}
              >
                <Text style={[styles.adviceText, { color: isCompatible ? "#1B5E20" : "#E65100" }]}>
                  {advice}
                </Text>
              </View>
            )}
          </View>

          {/* General Info */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>📋 ข้อมูลทั่วไป</Text>
            <View style={styles.infoTable}>
              <View style={styles.infoRow}>
                <Text style={[styles.infoLabel, { color: colors.muted }]}>หมวดหมู่</Text>
                <Text style={[styles.infoValue, { color: colors.foreground }]}>
                  {CATEGORY_LABELS[plant.category]}
                </Text>
              </View>
              <View style={[styles.infoRow, { borderTopWidth: 1, borderTopColor: colors.border }]}>
                <Text style={[styles.infoLabel, { color: colors.muted }]}>pH ต่ำสุด</Text>
                <Text style={[styles.infoValue, { color: colors.foreground }]}>{plant.phMin}</Text>
              </View>
              <View style={[styles.infoRow, { borderTopWidth: 1, borderTopColor: colors.border }]}>
                <Text style={[styles.infoLabel, { color: colors.muted }]}>pH สูงสุด</Text>
                <Text style={[styles.infoValue, { color: colors.foreground }]}>{plant.phMax}</Text>
              </View>
              <View style={[styles.infoRow, { borderTopWidth: 1, borderTopColor: colors.border }]}>
                <Text style={[styles.infoLabel, { color: colors.muted }]}>pH ที่เหมาะสมที่สุด</Text>
                <Text style={[styles.infoValue, { color: colors.primary }]}>
                  {((plant.phMin + plant.phMax) / 2).toFixed(1)}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 16,
    paddingBottom: 24,
    paddingHorizontal: 20,
    alignItems: "center",
    gap: 6,
  },
  headerBackBtn: {
    alignSelf: "flex-start",
    marginBottom: 8,
  },
  headerBackText: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 16,
    fontWeight: "600",
  },
  plantEmoji: {
    fontSize: 56,
  },
  plantName: {
    fontSize: 26,
    fontWeight: "800",
    color: "#FFFFFF",
    textAlign: "center",
  },
  plantCategory: {
    fontSize: 14,
    textAlign: "center",
  },
  body: {
    padding: 16,
    gap: 14,
  },
  card: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    gap: 12,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  cardSub: {
    fontSize: 13,
    marginTop: -6,
  },
  phRangeRow: {
    alignItems: "center",
  },
  phBadge: {
    flexDirection: "row",
    alignItems: "baseline",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  phBadgeMin: {
    fontSize: 28,
    fontWeight: "800",
  },
  phBadgeSep: {
    fontSize: 20,
    fontWeight: "400",
  },
  phBadgeMax: {
    fontSize: 28,
    fontWeight: "800",
  },
  rangeBarContainer: {
    position: "relative",
    paddingBottom: 22,
  },
  rangeTrack: {
    flexDirection: "row",
    height: 14,
    borderRadius: 7,
    overflow: "hidden",
  },
  rangeTrackSegment: {
    flex: 1,
  },
  rangeHighlight: {
    position: "absolute",
    top: 0,
    height: 14,
    borderRadius: 7,
    opacity: 0.85,
  },
  currentPHPin: {
    position: "absolute",
    top: -3,
    alignItems: "center",
    transform: [{ translateX: -4 }],
  },
  currentPHPinHead: {
    width: 8,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  rangeLabels: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  rangeLabelText: {
    fontSize: 11,
    color: "#9E9E9E",
    fontWeight: "500",
  },
  noteRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    borderRadius: 10,
    padding: 10,
    borderWidth: 1,
    gap: 8,
  },
  noteIcon: {
    fontSize: 16,
    marginTop: 1,
  },
  noteText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 19,
  },
  myPHRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  myPHInput: {
    width: 100,
    height: 52,
    borderRadius: 14,
    borderWidth: 2,
    fontSize: 24,
    fontWeight: "700",
    textAlign: "center",
    padding: 0,
  },
  compatBadge: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderRadius: 12,
    padding: 10,
  },
  compatText: {
    fontSize: 15,
    fontWeight: "700",
  },
  adviceBox: {
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
  },
  adviceText: {
    fontSize: 13,
    lineHeight: 21,
  },
  infoTable: {
    gap: 0,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
  },
  infoLabel: {
    fontSize: 14,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: "600",
  },
  notFoundText: {
    fontSize: 18,
    marginBottom: 16,
  },
  backBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  backBtnText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "600",
  },
});
