import { describe, it, expect } from "vitest";
import {
  getPlantsForPH,
  getPHStatus,
  getSoilAdjustmentAdvice,
  PLANTS,
} from "../constants/plants";

describe("getPlantsForPH", () => {
  it("returns plants compatible with pH 6.5", () => {
    const result = getPlantsForPH(6.5);
    expect(result.length).toBeGreaterThan(0);
    result.forEach((p) => {
      expect(p.phMin).toBeLessThanOrEqual(6.5);
      expect(p.phMax).toBeGreaterThanOrEqual(6.5);
    });
  });

  it("returns empty array for extreme pH 0", () => {
    const result = getPlantsForPH(0);
    expect(result).toHaveLength(0);
  });

  it("includes rice at pH 6.0", () => {
    const result = getPlantsForPH(6.0);
    const rice = result.find((p) => p.id === "rice");
    expect(rice).toBeDefined();
  });

  it("includes tea at pH 5.0 (acid-loving)", () => {
    const result = getPlantsForPH(5.0);
    const tea = result.find((p) => p.id === "tea");
    expect(tea).toBeDefined();
  });

  it("does not include tea at pH 7.0 (too alkaline)", () => {
    const result = getPlantsForPH(7.0);
    const tea = result.find((p) => p.id === "tea");
    expect(tea).toBeUndefined();
  });
});

describe("getPHStatus", () => {
  it("returns กรดจัดมาก for pH 3.5", () => {
    const status = getPHStatus(3.5);
    expect(status.label).toBe("กรดจัดมาก");
  });

  it("returns กรดจัด for pH 4.5", () => {
    const status = getPHStatus(4.5);
    expect(status.label).toBe("กรดจัด");
  });

  it("returns กรดอ่อน for pH 5.5", () => {
    const status = getPHStatus(5.5);
    expect(status.label).toBe("กรดอ่อน");
  });

  it("returns เป็นกลาง for pH 6.5", () => {
    const status = getPHStatus(6.5);
    expect(status.label).toBe("เป็นกลาง");
  });

  it("returns ด่างอ่อน for pH 7.5", () => {
    const status = getPHStatus(7.5);
    expect(status.label).toBe("ด่างอ่อน");
  });

  it("returns ด่างจัด for pH 9.0", () => {
    const status = getPHStatus(9.0);
    expect(status.label).toBe("ด่างจัด");
  });
});

describe("getSoilAdjustmentAdvice", () => {
  it("suggests increasing pH when soil is too acidic", () => {
    const advice = getSoilAdjustmentAdvice(4.5, 6.0, 7.0);
    expect(advice).toContain("กรดเกินไป");
    expect(advice).toContain("ปูนขาว");
  });

  it("suggests decreasing pH when soil is too alkaline", () => {
    const advice = getSoilAdjustmentAdvice(8.0, 5.5, 6.5);
    expect(advice).toContain("ด่างเกินไป");
    expect(advice).toContain("กำมะถัน");
  });

  it("returns suitable message when pH is in range", () => {
    const advice = getSoilAdjustmentAdvice(6.5, 6.0, 7.0);
    expect(advice).toContain("เหมาะสม");
  });
});

describe("PLANTS data integrity", () => {
  it("all plants have valid pH range (min < max)", () => {
    PLANTS.forEach((p) => {
      expect(p.phMin).toBeLessThan(p.phMax);
    });
  });

  it("all plants have pH values between 0 and 14", () => {
    PLANTS.forEach((p) => {
      expect(p.phMin).toBeGreaterThanOrEqual(0);
      expect(p.phMax).toBeLessThanOrEqual(14);
    });
  });

  it("all plants have unique IDs", () => {
    const ids = PLANTS.map((p) => p.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });
});
