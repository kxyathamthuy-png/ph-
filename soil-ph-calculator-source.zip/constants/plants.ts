export type PlantCategory =
  | "vegetable"
  | "field_crop"
  | "fruit_tree"
  | "flower"
  | "acid_loving"
  | "alkaline_tolerant";

export interface Plant {
  id: string;
  name: string;
  emoji: string;
  category: PlantCategory;
  phMin: number;
  phMax: number;
  notes?: string;
}

export const CATEGORY_LABELS: Record<PlantCategory, string> = {
  vegetable: "🌱 พืชผักทั่วไป",
  field_crop: "🌾 พืชไร่",
  fruit_tree: "🌳 ไม้ผล",
  flower: "🌸 ไม้ดอก/ไม้ประดับ",
  acid_loving: "🌿 พืชที่ชอบดินกรดจัด",
  alkaline_tolerant: "🌵 พืชที่ทนดินด่าง",
};

export const PLANTS: Plant[] = [
  // พืชผักทั่วไป
  { id: "pak-kat", name: "ผักกาด", emoji: "🥬", category: "vegetable", phMin: 6.0, phMax: 7.0 },
  { id: "kana", name: "คะน้า", emoji: "🥦", category: "vegetable", phMin: 6.0, phMax: 7.0 },
  { id: "kuang-tung", name: "กวางตุ้ง", emoji: "🥬", category: "vegetable", phMin: 6.0, phMax: 7.0 },
  { id: "tomato", name: "มะเขือเทศ", emoji: "🍅", category: "vegetable", phMin: 5.5, phMax: 6.8 },
  { id: "cucumber", name: "แตงกวา", emoji: "🥒", category: "vegetable", phMin: 5.5, phMax: 7.0 },
  { id: "chili", name: "พริก", emoji: "🌶️", category: "vegetable", phMin: 6.0, phMax: 6.8 },

  // พืชไร่
  { id: "rice", name: "ข้าว", emoji: "🌾", category: "field_crop", phMin: 5.5, phMax: 6.5 },
  { id: "corn", name: "ข้าวโพด", emoji: "🌽", category: "field_crop", phMin: 5.5, phMax: 7.0 },
  { id: "sugarcane", name: "อ้อย", emoji: "🎋", category: "field_crop", phMin: 6.0, phMax: 7.5 },

  // ไม้ผล
  { id: "mango", name: "มะม่วง", emoji: "🥭", category: "fruit_tree", phMin: 5.5, phMax: 7.5 },
  { id: "banana", name: "กล้วย", emoji: "🍌", category: "fruit_tree", phMin: 5.0, phMax: 7.0 },
  { id: "orange", name: "ส้ม", emoji: "🍊", category: "fruit_tree", phMin: 5.5, phMax: 6.5 },

  // ไม้ดอก/ไม้ประดับ
  { id: "rose", name: "กุหลาบ", emoji: "🌹", category: "flower", phMin: 6.0, phMax: 6.5 },
  { id: "orchid", name: "กล้วยไม้", emoji: "🌺", category: "flower", phMin: 5.5, phMax: 6.5 },
  {
    id: "hydrangea-blue",
    name: "ไฮเดรนเยีย (ดอกสีฟ้า)",
    emoji: "💙",
    category: "flower",
    phMin: 5.0,
    phMax: 5.5,
    notes: "ดินกรดทำให้ดอกเป็นสีฟ้า",
  },
  {
    id: "hydrangea-pink",
    name: "ไฮเดรนเยีย (ดอกสีชมพู)",
    emoji: "🩷",
    category: "flower",
    phMin: 6.0,
    phMax: 6.5,
    notes: "ดินด่างทำให้ดอกเป็นสีชมพู",
  },

  // พืชที่ชอบดินกรดจัด
  { id: "tea", name: "ชา", emoji: "🍵", category: "acid_loving", phMin: 4.5, phMax: 5.5 },
  { id: "pineapple", name: "สับปะรด", emoji: "🍍", category: "acid_loving", phMin: 4.5, phMax: 6.0 },

  // พืชที่ทนดินด่าง
  {
    id: "cactus",
    name: "กระบองเพชร",
    emoji: "🌵",
    category: "alkaline_tolerant",
    phMin: 6.0,
    phMax: 8.0,
    notes: "บางชนิดทนได้ถึง pH 8.0",
  },
];

export function getPlantsForPH(ph: number): Plant[] {
  return PLANTS.filter((p) => ph >= p.phMin && ph <= p.phMax);
}

export function getPHStatus(ph: number): {
  label: string;
  color: string;
  description: string;
} {
  if (ph < 4.0) return { label: "กรดจัดมาก", color: "#C62828", description: "ดินมีความเป็นกรดสูงมาก ไม่เหมาะสำหรับพืชส่วนใหญ่" };
  if (ph < 5.0) return { label: "กรดจัด", color: "#E53935", description: "ดินเป็นกรดจัด เหมาะสำหรับพืชบางชนิดเท่านั้น" };
  if (ph < 6.0) return { label: "กรดอ่อน", color: "#FB8C00", description: "ดินเป็นกรดอ่อน เหมาะสำหรับพืชหลายชนิด" };
  if (ph <= 7.0) return { label: "เป็นกลาง", color: "#2E7D32", description: "ดินมีความเป็นกลาง เหมาะสำหรับพืชส่วนใหญ่" };
  if (ph <= 8.0) return { label: "ด่างอ่อน", color: "#1565C0", description: "ดินเป็นด่างอ่อน เหมาะสำหรับพืชบางชนิด" };
  return { label: "ด่างจัด", color: "#4527A0", description: "ดินเป็นด่างจัด ไม่เหมาะสำหรับพืชส่วนใหญ่" };
}

export function getSoilAdjustmentAdvice(
  currentPH: number,
  targetMin: number,
  targetMax: number
): string {
  const targetMid = (targetMin + targetMax) / 2;
  if (currentPH < targetMin) {
    const diff = (targetMin - currentPH).toFixed(1);
    return `ดินเป็นกรดเกินไป ควรเพิ่มความเป็นด่าง (เพิ่ม pH ประมาณ ${diff} หน่วย)\n• ใส่ปูนขาว (CaCO₃) หรือปูนมาร์ล\n• ใส่เถ้าไม้หรือเถ้าฟาง\n• ใส่ปุ๋ยหินฟอสเฟต`;
  }
  if (currentPH > targetMax) {
    const diff = (currentPH - targetMax).toFixed(1);
    return `ดินเป็นด่างเกินไป ควรเพิ่มความเป็นกรด (ลด pH ประมาณ ${diff} หน่วย)\n• ใส่กำมะถัน (Sulfur)\n• ใส่ปุ๋ยแอมโมเนียมซัลเฟต\n• ใส่อินทรีย์วัตถุ เช่น พีทมอส`;
  }
  return `ค่า pH ของดินอยู่ในช่วงที่เหมาะสม (${targetMin}–${targetMax})\nไม่จำเป็นต้องปรับปรุงดิน`;
}
