# Soil pH Calculator — TODO

- [x] กำหนด theme สีเขียวธรรมชาติใน theme.config.js
- [x] สร้างโลโก้แอปด้วย AI image generation
- [x] อัปเดต app.config.ts (appName, logoUrl)
- [x] สร้างไฟล์ข้อมูลพืช constants/plants.ts
- [x] สร้าง icon mapping ใน icon-symbol.tsx (leaf, drop, info)
- [x] พัฒนา Tab bar 4 แท็บ (หน้าหลัก, ตรวจสอบ pH, พืช, ข้อมูล)
- [x] พัฒนา Home Screen (หน้าหลัก)
- [x] พัฒนา pH Checker Screen พร้อม Slider และผลลัพธ์
- [x] พัฒนา Plant List Screen พร้อม Search และหมวดหมู่
- [x] พัฒนา Plant Detail Screen
- [x] พัฒนา Info Screen (ข้อมูลเกี่ยวกับ pH)
- [x] สร้าง pH Scale visual component
- [x] บันทึก checkpoint
